package com.main.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.main.feign.OderFeignClient;
import com.main.model.Invoice;
import com.main.model.Order;
import com.main.model.Product;
import com.main.service.InvoiceServiceIntf;


@RestController
@RequestMapping("/invoice")
public class InvoiceController {

	@Autowired
	private InvoiceServiceIntf invoiceSer;
	@Autowired
	private OderFeignClient orderFeignClient;

	@PostMapping("/saveInvoice")
	public ResponseEntity<String> saveRegister(@RequestBody Invoice reg2) {
		double totalAmount = orderFeignClient.getTotalAmount(reg2.getOrderId());
		
		
		/*call order feign client and fetch order object by orderId comming from invoiceTable
		 * after getting order object check the order statement*/
		
		invoiceSer.saveInvoiceDetails(reg2,totalAmount);
		
		return new ResponseEntity<String>("Invoice Added Successfully", HttpStatus.CREATED);
	}
	
	
	
	/*@GetMapping("/invoice/{invoiceId}")
    public ResponseEntity<Optional<Invoice>> getUserByPathh(@PathVariable("invoiceId") int invoiceId, Product prod, Order ord,
            Invoice ino) {
        System.out.println(invoiceId);
        invoiceSer.saveRegistrationDetails(ino);
        Optional<Invoice> option = invoiceSer.viewOrderDetails(invoiceId);
        if (option.isPresent())
            return new ResponseEntity<>(option, HttpStatus.OK);
        else
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
	*/
	
}
