package com.main.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.main.model.Invoice;


@Repository
public interface InvoiceServerRepository extends JpaRepository<Invoice, Integer>{

	
}
