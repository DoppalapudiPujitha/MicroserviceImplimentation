package com.main.service;

import java.util.List;
import java.util.Optional;

import com.main.model.Invoice;

public interface InvoiceServiceIntf {

	void saveInvoiceDetails(Invoice reg2, double totalAmount);

	List<Invoice> fetchOrderData();

	Optional<Invoice> buyUsingInvoiceId(int invoiceId);

	Optional<Invoice> viewOrderDetails(int invoiceId);

}
