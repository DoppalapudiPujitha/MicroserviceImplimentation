package com.main.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.main.dao.InvoiceServerRepository;
import com.main.model.Invoice;
import com.main.model.Order;
import com.main.model.Product;

@Service
@Transactional
public class InvoiceServiceImpl implements InvoiceServiceIntf{
	@Autowired
	InvoiceServerRepository invoiceRepo;
	
	public void saveInvoiceDetails(Invoice reg2,double totalAmount) {
		reg2.setTotalAmount(totalAmount);
		invoiceRepo.save(reg2);
	}

	public List<Invoice> fetchOrderData() {
		return (List<Invoice>) invoiceRepo.findAll();
	}

	public Optional<Invoice> buyUsingInvoiceId(int invoiceId) {
		return invoiceRepo.findById(invoiceId);
	}

	

	public Optional<Invoice> viewOrderDetails(int invoiceId) {
		return invoiceRepo.findById(invoiceId);
	}


}
