package com.main.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.main.dao.ProductRepository;
import com.main.model.Product;
@Service
@Transactional
public class ProdServiceImpl implements ProdServiceIntf{
@Autowired
ProductRepository repData;
	public Optional<Product> viewOrderDetails(int productId) {
		return repData.findById(productId);
	}

}
