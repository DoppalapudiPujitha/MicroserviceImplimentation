package com.main.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.main.dao.ProductServerRepository;
import com.main.model.Product;

@Service
@Transactional
public class ProductServiceImpl implements ProductServiceIntf{
	
@Autowired
private ProductServerRepository repo;

	public void saveProductDetails(Product reg) {
		repo.save(reg);
	
	}

	public List<Product> fetchData() {
		return (List<Product>) repo.findAll();
	}

	public Optional<Product> buyUsingId(int productId) {
		return repo.findById(productId);
	}

	
}
