package com.main.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.main.model.Product;
import com.main.service.ProductServiceIntf;

@RestController
@RequestMapping("/product")
public class ProductController {

	@Autowired
	private ProductServiceIntf registerService;

	@PostMapping("/saveProduct")
	public ResponseEntity<String> saveRegister(@RequestBody Product reg) {
		registerService.saveProductDetails(reg);
		return new ResponseEntity<String>("Product Added Successfully", HttpStatus.CREATED);
	}
	
	@GetMapping("/getProduct")
    public ResponseEntity<List<Product>> fetchData() {
        List<Product> list = registerService.fetchData();
        if (list.size() == 0) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>(list, HttpStatus.OK);
    }
	
	
	@GetMapping("/buyUsingId/{productId}")
    public ResponseEntity<Product> buyUsingId(@PathVariable("productId") int productId) {
		Product product = registerService.buyUsingId(productId).get();
        if (product!=null) 
            return new ResponseEntity<>(product, HttpStatus.OK);
        else
        	return new ResponseEntity<>(HttpStatus.NOT_FOUND);
}
}
