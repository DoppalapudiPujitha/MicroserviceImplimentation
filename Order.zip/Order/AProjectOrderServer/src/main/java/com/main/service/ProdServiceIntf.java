package com.main.service;

import java.util.Optional;

import com.main.model.Product;

public interface ProdServiceIntf {

	Optional<Product> viewOrderDetails(int productId);

}
