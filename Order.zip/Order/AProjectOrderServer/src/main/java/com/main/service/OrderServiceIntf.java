package com.main.service;

import java.util.List;
import java.util.Optional;

import com.main.model.Order;

public interface OrderServiceIntf {

	void saveOrderDetails(Order reg1);

	List<Order> fetchProductData();

	Optional<Order> buyUsingOrderId(int orderId);


}
